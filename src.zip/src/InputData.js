export const plannedTasks = ["Column1","Column2","Column3","Column4","Column5","Column6"];


export const dropdownlist = [
    { label: "Albania", value: 355 },
    { label: "Argentina", value: 54 },
    { label: "Austria", value: 43 },
    { label: "Cocos Islands", value: 61 },
    { label: "Kuwait", value: 965 },
    { label: "Sweden", value: 46 },
    { label: "Venezuela", value: 58 }
  ];

  
export const conditiondropdwon = [
    { label: "And", value: 1 },
    { label: "OR", value: 2 }
  ];
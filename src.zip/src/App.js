import logo from './logo.svg';
import React, { Component } from 'react';
import './App.css';
import './style.css';
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
//import AddDeleteTableRows from "./add-delete-table-rows/AddDeletetableRows";
import AddDeleteTableRows from "../src/add-delete-table-rows/AddDeleteTableRows"
import Tablegrid from "../src/Tablegrid"
import DragAndDrop from './DragAndDrop';
import Test2 from '../src/Test2'
import Test3 from '../src/Test3'

class App extends Component {
  render() {
    return (
<div className="container">
        <h1>Home</h1>
        <hr />
        <div>
          <div className="col-12">
            <Test3 />
          </div>
        </div>
      </div>
      
    );
  }
}

export default App;

import React, { Component } from "react";
import { Draggable, Droppable } from "react-drag-and-drop";

class DragAndDrop extends Component {
  constructor(props) {
    super(props);
    this.onDrop = this.onDrop.bind(this);
    this.state = {
      fruit1: ["Apple", "Banana", "Mango"],
      fruit2: [],
      user: {},
      errors: {}
    };
  }



  onDrop(data) {
    // => banana
    let temp = this.state.fruit2.concat(data.fruit);

    this.setState({ fruit2: temp });
    console.log('start');
    console.log(temp);
    console.log('end');
  }
  render() {
    return (
      <div>
        <ul style={{ border: "1px solid" }}>
          {this.state.fruit1.map((item, index) => {
            console.log(item);
            return (
              <li key={index}>
                <Draggable type="fruit" data={item}>
                  <li>{item}</li>
                </Draggable>
              </li>
            );
          })}
        </ul>
        <Droppable
          types={["fruit"]} // <= allowed drop types
          onDrop={this.onDrop.bind(this)}
        >
          <ul
            className="Smoothie"
            style={{ border: "1px solid", minHeight: "50px" }}
          >
            {this.state.fruit2.map((item, index) => {
              console.log(item);
              return <li key={index}>{item}</li>;
            })}
          </ul>
        </Droppable >
      </div>
    );
  }
}

export default DragAndDrop;

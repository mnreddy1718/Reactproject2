import React, { Component } from "react";
import { render } from "react-dom";
import { Draggable, Droppable } from "react-drag-and-drop";
import { plannedTasks, dropdownlist,conditiondropdwon } from '../src/InputData'
import Select from 'react-select';



class Test2 extends Component {

    constructor(props) {
        super(props);
        this.state = {
          columnsList: plannedTasks,
          seconddropdown: conditiondropdwon,
          countries: dropdownlist,
          errors: {},
          user: {},
          rows: [{}]
        };
    }

    handleChange = idx => e => {
      const { name, value } = e.target;
      const rows = [...this.state.rows];
      rows[idx] = {
        [name]: value
      };
      this.setState({
        rows
      });
      console.log(rows);
    };
    
    // handleRemoveRow = () => {
    //   this.setState({
    //     rows: this.state.rows.slice(0, -1)
    //   });
    // };

    handleRemoveSpecificRow = (idx) => () => {
      const rows = [...this.state.rows]
      rows.splice(idx, 1)
      this.setState({ rows })
    }

    getvalueselected = (valuess) => () => {
      
        console.log('bcsj');
        console.log(valuess);
        const item = {
            name: valuess,
            mobile: ""
          };
          this.setState({
            rows: [...this.state.rows, item]
          });
      }

    render() {
      return (
        <div>
          <div className="container">
            <div className="row clearfix">
              <div className="col-md-4 column">
                <ul style={{ border: "1px solid" }}>
                  {this.state.columnsList.map((item, index) => {
                      return (
                      <li key={index}>
                          <li onClick={this.getvalueselected(item)}>{item}</li>
                      </li>
                      );
                  })}
                </ul>
              </div>
              <div className="col-md-8 column">
                <table
                  className="table table-bordered table-hover"
                  id="tab_logic">
                  <thead>
                  </thead>
                  <tbody>
                    {this.state.rows.map((item, idx) => (
                      <><tr id="addr0" key={idx}>
                        <td>
                          <input
                            type="text"
                            name="Name"
                            value={this.state.rows[idx].name}
                            onChange={this.handleChange(idx)}
                            className="form-control" />

                        </td>
                        <td>
                          <Select options={this.state.countries} />
                        </td>
                        <td>
                          <input
                            type="text"
                            name="mobile"
                            value={this.state.rows[idx].mobile}
                            onChange={this.handleChange(idx)}
                            className="form-control" />
                        </td>
                        <td>
                          <button
                            className="btn btn-outline-danger btn-sm"
                            onClick={this.handleRemoveSpecificRow(idx)}
                          >
                            Remove
                          </button>
                        </td>
                      </tr>
                        <div>
                          <Select options={this.state.seconddropdown} />
                        </div>
                      </>
                    ))}
                  </tbody>
                </table>
                <button className="btn btn-primary">
                  Save as Template
                </button>
                <button
                  className="btn btn-danger float-right"
                >
                  Generate Query
                </button>
              </div>
            </div>
          </div>
        </div>
      );
    }
  }

  export default Test2;